
// SCENE
const scene = new THREE.Scene();

// CAMERA
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.z = 5;

// RENDERER
const renderer = new THREE.WebGLRenderer({
  canvas: document.getElementById("hero-canvas"),
  alpha: true,
  antialias: true
});

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);

// LIGHT
const light = new THREE.PointLight(0xa855f7, 2);
light.position.set(5, 5, 5);
scene.add(light);

// 3D GEOMETRY (placeholder for avatar/logo)
const geometry = new THREE.IcosahedronGeometry(1.2, 1);
const material = new THREE.MeshStandardMaterial({
  color: 0xa855f7,
  wireframe: true
});

const mesh = new THREE.Mesh(geometry, material);
scene.add(mesh);

//partcles
const particlesGeometry = new THREE.BufferGeometry();
const particlesCount = 800;

const posArray = new Float32Array(particlesCount * 3);

for (let i = 0; i < particlesCount * 3; i++) {
  posArray[i] = (Math.random() - 0.5) * 10;
}

particlesGeometry.setAttribute(
  "position",
  new THREE.BufferAttribute(posArray, 3)
);

const particlesMaterial = new THREE.PointsMaterial({
  size: 0.015,
  color: 0xffffff
});

const particlesMesh = new THREE.Points(
  particlesGeometry,
  particlesMaterial
);

scene.add(particlesMesh);

//animated loop
function animate() {
  requestAnimationFrame(animate);

  mesh.rotation.x += 0.002;
  mesh.rotation.y += 0.003;

  particlesMesh.rotation.y += 0.0005;

  renderer.render(scene, camera);
}

animate();


const text = "I Build Interactive Web Experiences";
let index = 0;

function typingEffect() {
  if (index < text.length) {
    document.getElementById("typing-text").textContent += text[index];
    index++;
    setTimeout(typingEffect, 70);
  }
}

typingEffect();

//scroll based hero movememnt
window.addEventListener("scroll", () => {
  const scrollY = window.scrollY;

  mesh.position.y = scrollY * -0.002;
  particlesMesh.rotation.x = scrollY * 0.0003;
});

//responsiveness fix
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
// skills cards rings
 
  const skillCards = document.querySelectorAll('.skill-card');

  const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const percent = entry.target.dataset.percent;
        const progress = entry.target.querySelector('.progress');

        progress.style.strokeDashoffset = 100 - percent;
        entry.target.classList.add('show');

        // Optional: stop observing once animated
        skillObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });

  skillCards.forEach(card => skillObserver.observe(card));


 // scroll+model butoon on projects page 
  /* FILTER */
  const buttons = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('.project-card');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;

      cards.forEach(card => {
        if (filter === 'all' || card.classList.contains(filter)) {
          card.style.display = 'block';
          setTimeout(() => card.classList.add('show'), 50);
        } else {
          card.classList.remove('show');
          setTimeout(() => card.style.display = 'none', 300);
        }
      });
    });
  });

  /* SCROLL ANIMATION */
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('show');
    });
  }, { threshold: 0.2 });

  cards.forEach(card => observer.observe(card));

  /* MODAL */
  function openModal(title) {
    alert("Open project: " + title);
  }
  // =========================
  // TESTIMONIAL CAROUSEL
  // =========================
  let Index = 0;
  const testimonials = document.querySelectorAll('.testimonial-card');
  let autoSlide;

  function updateCarousel() {
    testimonials.forEach((card, i) => {
      card.classList.toggle('active', i === index);
    });
  }

  function nextTestimonial() {
    Index = (Index + 1) % testimonials.length;
    updateCarousel();
  }

  function prevTestimonial() {
    Index = (Index - 1 + testimonials.length) % testimonials.length;
    updateCarousel();
  }

  // AUTO SLIDE
  function startAutoCarousel() {
    autoSlide = setInterval(nextTestimonial, 4000); // 4s
  }

  function stopAutoCarousel() {
    clearInterval(autoSlide);
  }

  // INIT
  updateCarousel();
  startAutoCarousel();

  // PAUSE ON HOVER (BEST UX)
  testimonials.forEach(card => {
    card.addEventListener('mouseenter', stopAutoCarousel);
    card.addEventListener('mouseleave', startAutoCarousel);
  });



  //submit
  function submitForm(e){
    e.preventDefault();
    const btn = document.querySelector('.submit-btn');
    btn.classList.add('success');
  }
//dark
document.documentElement.classList.toggle('dark');
// scroll annimation 
gsap.from(".section",{opacity:0,y:60,scrollTrigger:".section"})
